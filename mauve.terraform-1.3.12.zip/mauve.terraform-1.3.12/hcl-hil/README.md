# vscode-terraform/hcl-hil

This directory contains the docker files and some small amount
of Go code required to cross compile the official hcl/hil libraries
into JS using GopherJS.

It is referenced in `../gulpfile.js`